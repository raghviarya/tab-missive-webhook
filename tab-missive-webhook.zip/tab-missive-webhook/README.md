# Tab Missive Webhook (Vercel)

This is a tiny, deploy-ready project for drafting Missive replies with OpenAI using the **full email thread**.

## Files
- `api/missive-inbound.js` — Vercel Serverless Function (Node 18+)
- `package.json` — minimal config

## Environment variables (set in Vercel → Project → Settings → Environment Variables)
- `MISSIVE_API_TOKEN` — from Missive Settings → API
- `OPENAI_API_KEY` — your OpenAI key
- `MISSIVE_HOOK_SECRET` — (optional) the same secret you enter in the Missive Rule; leave empty to skip signature verification

## Local test
```
vercel dev
# in another terminal:
curl -X POST http://localhost:3000/api/missive-inbound   -H 'Content-Type: application/json'   -d '{"conversation":{"id":"CONVO_ID","subject":"Test"},"latest_message":{"subject":"Test","preview":"Hola","from_field":{"address":"test@example.com"}}}'
```
(Use a real `conversation.id` from Missive to see a draft appear.)
