// api/missive-inbound.js
const crypto = require('crypto')

const MISSIVE_API = 'https://public.missiveapp.com/v1'

function verifySignature(raw, headerSig, secret) {
  if (!secret) return true
  if (!headerSig) return false
  const computed = 'sha256=' + crypto.createHmac('sha256', secret).update(raw).digest('hex')
  const a = Buffer.from(computed)
  const b = Buffer.from(headerSig)
  if (a.length !== b.length) return false
  return crypto.timingSafeEqual(a, b)
}

function stripHtml(html = '') {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<\/?(?:br|p|div|li|ul|ol|table|tr|td|th|hr)\b[^>]*>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

function clampText(s, maxChars) {
  if (!s) return ''
  if (s.length <= maxChars) return s
  return s.slice(0, maxChars) + '\n[...truncated for length...]'
}

async function fetchThread(convoId, token) {
  // Try query form first
  let url = `${MISSIVE_API}/messages?search[conversation]=${encodeURIComponent(convoId)}`
  let resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } })
  if (!resp.ok) {
    // Fallback to nested route if available in your account
    url = `${MISSIVE_API}/conversations/${encodeURIComponent(convoId)}/messages`
    resp = await fetch(url, { headers: { Authorization: `Bearer ${token}` } })
  }
  if (!resp.ok) {
    const t = await resp.text()
    throw new Error(`Missive messages fetch error: ${t}`)
  }
  const j = await resp.json()
  return j.messages || j || []
}

module.exports = async (req, res) => {
  // Optional health check
  if (req.method === 'GET') return res.status(200).send('ok')

  if (req.method !== 'POST') return res.status(405).send('Method not allowed')

  const rawBody = JSON.stringify(req.body || {})
  const signature = req.headers['x-hook-signature']
  const ok = verifySignature(rawBody, signature, process.env.MISSIVE_HOOK_SECRET)
  if (!ok) return res.status(401).send('Invalid signature')

  try {
    const conversation = req.body?.conversation
    const latest = req.body?.latest_message
    if (!conversation?.id || !latest) {
      return res.status(400).json({ error: 'Missing conversation/latest_message' })
    }

    const convoId = conversation.id
    const all = await fetchThread(convoId, process.env.MISSIVE_API_TOKEN)

    // Sort by created_at ascending
    all.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())

    // Build readable thread text
    const thread = all.map(m => {
      const who = (m.from_field?.name || m.from_field?.address || 'Unknown')
      const when = m.created_at || ''
      const body = m.text ? m.text : stripHtml(m.body || '')
      return `From: ${who}\nDate: ${when}\n---\n${body}\n`
    }).join('\n------------------------\n')

    const threadForPrompt = clampText(thread, 12000)

    const systemInstruction = `
Eres un agente de soporte para Tab. Responde en español claro y profesional.
- Sé breve pero completo; usa HTML simple (<p>, <ul>, <li>, <strong>).
- No prometas fechas ni funciones futuras; ofrece alternativas o pasos.
- Si faltan datos (ID de cuenta, URL, capturas), pide solo lo esencial en bullets.
- No incluyas firma; no repitas todo el hilo.
`.trim()

    const userPrompt = `
Redacta una respuesta por email (HTML) considerando TODO el historial de esta conversación.

Hilo (completo, más reciente al final):
${threadForPrompt}

Instrucciones adicionales:
- Sé amable y directo.
- Si el remitente habla de "Checkout Flow", usa lenguaje de soporte (no marketing).
- Si es un follow-up, reconoce brevemente el contexto anterior.
`.trim()

    // Call OpenAI Responses API
    const openaiResp = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        input: [
          { role: 'system', content: systemInstruction },
          { role: 'user', content: userPrompt }
        ],
        max_output_tokens: 800
      })
    })
    if (!openaiResp.ok) {
      const t = await openaiResp.text()
      throw new Error(`OpenAI error: ${t}`)
    }
    const oj = await openaiResp.json()
    const html = oj.output_html || (oj.output_text ? `<p>${oj.output_text.replace(/\n/g, '<br/>')}</p>` : '<p>Gracias por tu mensaje.</p>')

    // Create draft
    const draftResp = await fetch(`${MISSIVE_API}/drafts`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.MISSIVE_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        drafts: {
          conversation: convoId,
          quote_previous_message: false,
          subject: `Re: ${(conversation.subject || latest.subject || '').trim()}`,
          body: html
        }
      })
    })
    if (!draftResp.ok) {
      const t = await draftResp.text()
      throw new Error(`Missive draft error: ${t}`)
    }

    return res.status(200).json({ ok: true, conversation: convoId })
  } catch (e) {
    console.error(e)
    return res.status(500).json({ error: String(e.message || e) })
  }
}
